# Architecture

```text
Synthetic Data
     |
     v
Data Validation
     |
     +----> Demand Analytics
     |
     +----> Inventory Analytics
     |
     +----> Supplier Analytics
     |
     +----> Delivery Analytics
     |
     v
Business KPI Layer
     |
     v
Web Dashboard
```

Python handles analytical processing, Java demonstrates business logic, SQL handles relational analysis, and the web layer presents selected KPIs.
