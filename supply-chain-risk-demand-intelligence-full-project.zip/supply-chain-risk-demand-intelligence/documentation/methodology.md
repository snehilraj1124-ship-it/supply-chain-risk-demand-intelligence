# Methodology

## Demand
Order quantities are aggregated by product and category.

## Inventory
A simple turnover proxy is calculated as sold units divided by average opening and closing stock.

## Supplier
A transparent illustrative score combines on-time delivery, defect rate and lead time.

## Risk
Risk categories are analytical labels for this synthetic dataset and are not production procurement policies.
