-- Demand by product
SELECT product_id, SUM(quantity) AS units_sold
FROM orders
GROUP BY product_id
ORDER BY units_sold DESC;

-- Delivery delay rate
SELECT
    AVG(CASE WHEN status = 'Delayed' THEN 1.0 ELSE 0.0 END) * 100 AS delay_rate
FROM orders;

-- Supplier performance
SELECT supplier_id,
       AVG(on_time_rate) AS on_time_rate,
       AVG(defect_rate) AS defect_rate,
       AVG(avg_lead_days) AS average_lead_days
FROM suppliers
GROUP BY supplier_id;

-- Inventory risk
SELECT product_id, warehouse, closing_stock, stockout_days
FROM inventory
WHERE stockout_days > 0
ORDER BY stockout_days DESC;
