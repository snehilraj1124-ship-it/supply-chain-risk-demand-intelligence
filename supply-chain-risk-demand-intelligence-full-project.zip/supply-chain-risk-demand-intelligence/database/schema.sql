CREATE TABLE products (
    product_id VARCHAR(10) PRIMARY KEY,
    product_name VARCHAR(100),
    category VARCHAR(50),
    unit_cost DECIMAL(10,2),
    selling_price DECIMAL(10,2),
    reorder_level INT
);

CREATE TABLE suppliers (
    supplier_id VARCHAR(10) PRIMARY KEY,
    supplier_name VARCHAR(100),
    category VARCHAR(50),
    avg_lead_days INT,
    on_time_rate DECIMAL(5,4),
    defect_rate DECIMAL(5,4),
    cost_index DECIMAL(6,3),
    risk_level VARCHAR(20)
);

CREATE TABLE orders (
    order_id VARCHAR(10) PRIMARY KEY,
    order_date DATE,
    product_id VARCHAR(10),
    warehouse VARCHAR(50),
    quantity INT,
    unit_price DECIMAL(10,2),
    delivery_days INT,
    status VARCHAR(20)
);

CREATE TABLE inventory (
    inventory_id VARCHAR(10) PRIMARY KEY,
    product_id VARCHAR(10),
    warehouse VARCHAR(50),
    opening_stock INT,
    received_units INT,
    sold_units INT,
    closing_stock INT,
    stockout_days INT
);
