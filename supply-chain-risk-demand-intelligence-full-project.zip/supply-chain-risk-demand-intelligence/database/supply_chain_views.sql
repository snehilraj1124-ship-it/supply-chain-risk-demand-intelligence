CREATE VIEW warehouse_inventory_summary AS
SELECT warehouse,
       SUM(opening_stock) AS opening_units,
       SUM(received_units) AS received_units,
       SUM(sold_units) AS sold_units,
       SUM(closing_stock) AS closing_units,
       SUM(stockout_days) AS total_stockout_days
FROM inventory
GROUP BY warehouse;
