def inventory_status(stock, reorder_level):
    if stock <= reorder_level:
        return "Reorder"
    if stock <= reorder_level * 1.25:
        return "Monitor"
    return "Healthy"

def test_reorder():
    assert inventory_status(90, 100) == "Reorder"

def test_healthy():
    assert inventory_status(200, 100) == "Healthy"
