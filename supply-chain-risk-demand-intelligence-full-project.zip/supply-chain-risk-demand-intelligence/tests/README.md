# Tests

The test folder contains basic validation examples for inventory planning logic.

Run with:

```bash
pytest
```
