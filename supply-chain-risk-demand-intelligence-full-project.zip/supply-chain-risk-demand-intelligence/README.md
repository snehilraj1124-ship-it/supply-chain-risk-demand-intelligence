# Supply Chain Risk & Demand Intelligence Platform

An end-to-end educational analytics platform for studying demand, inventory, suppliers, procurement, delivery performance and operational risk using synthetic data.

## Technology Stack
- Python: demand and KPI analytics
- Java: supplier/risk business logic
- SQL: relational analysis
- HTML/CSS/JavaScript: interactive dashboard
- CSV: synthetic supply-chain data

## Core Analytics
- Demand trends
- Inventory turnover
- Stock-out risk
- Supplier performance
- Lead-time analysis
- Delivery delays
- Procurement cost
- Supplier risk segmentation
- Warehouse performance

## Disclaimer
This project uses synthetic/sample data for educational and portfolio purposes. It is not a production forecasting or procurement decision system.
