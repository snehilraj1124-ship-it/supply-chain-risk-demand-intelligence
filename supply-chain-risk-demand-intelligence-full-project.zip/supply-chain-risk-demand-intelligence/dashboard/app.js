const dashboardMetrics = {
  products: 10,
  orders: 10,
  suppliers: 6,
  delayedOrders: 2
};

console.log("Supply Chain dashboard loaded", dashboardMetrics);
