# Demand Intelligence Report

## Summary

The sample dataset contains product-level orders across Delhi, Mumbai and Bengaluru.

## Analysis Areas

- Units sold by product
- Revenue contribution
- Category demand
- Warehouse demand
- Average delivery time

The Python demand module generates a product-level summary in `reports/demand_summary.csv`.
