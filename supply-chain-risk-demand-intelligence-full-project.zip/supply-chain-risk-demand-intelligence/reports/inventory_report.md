# Inventory Risk Report

Inventory monitoring focuses on:

- Opening stock
- Received units
- Sold units
- Closing stock
- Stock-out days
- Turnover proxy

Products with repeated stock-out days should be reviewed for replenishment planning.
