# Supplier Performance Report

Supplier evaluation considers:

- On-time delivery rate
- Defect rate
- Average lead time
- Cost index

The scoring model is illustrative and designed for portfolio demonstration.
