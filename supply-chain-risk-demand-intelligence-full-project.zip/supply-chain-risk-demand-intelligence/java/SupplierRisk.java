package supplychain;

public class SupplierRisk {
    public static double score(double onTimeRate, double defectRate, int leadDays) {
        return (onTimeRate * 70) + ((1 - defectRate) * 20) + ((1.0 / leadDays) * 10);
    }

    public static String category(double score) {
        if (score >= 85) return "Low Risk";
        if (score >= 75) return "Medium Risk";
        return "High Risk";
    }
}
