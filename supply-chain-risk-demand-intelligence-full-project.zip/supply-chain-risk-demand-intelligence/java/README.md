# Java Modules

The Java layer demonstrates supplier-risk scoring and inventory planning logic.

Example compilation:

```bash
javac -d . SupplierRisk.java SupplyChainApp.java InventoryPlanner.java
java supplychain.SupplyChainApp
```
