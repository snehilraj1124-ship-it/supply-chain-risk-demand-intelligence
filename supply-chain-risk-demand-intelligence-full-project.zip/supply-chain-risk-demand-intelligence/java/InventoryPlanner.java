package supplychain;

public class InventoryPlanner {
    public static String recommendation(int stock, int reorderLevel) {
        if (stock <= reorderLevel) return "Reorder";
        if (stock <= reorderLevel * 1.25) return "Monitor";
        return "Healthy";
    }

    public static void main(String[] args) {
        System.out.println(recommendation(145, 100));
    }
}
