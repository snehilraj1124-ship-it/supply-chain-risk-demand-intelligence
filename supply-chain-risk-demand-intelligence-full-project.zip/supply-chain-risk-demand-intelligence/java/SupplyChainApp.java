package supplychain;

public class SupplyChainApp {
    public static void main(String[] args) {
        double score = SupplierRisk.score(0.88, 0.025, 9);
        System.out.println("Supplier Score: " + String.format("%.2f", score));
        System.out.println("Risk Category: " + SupplierRisk.category(score));
    }
}
