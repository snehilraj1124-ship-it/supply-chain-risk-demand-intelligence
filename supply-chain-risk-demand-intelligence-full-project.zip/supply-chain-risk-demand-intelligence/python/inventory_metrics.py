import pandas as pd

inventory = pd.read_csv("../data/inventory.csv")

inventory["turnover_proxy"] = (
    inventory["sold_units"] /
    inventory[["opening_stock", "closing_stock"]].mean(axis=1)
)

inventory["stock_risk"] = inventory["stockout_days"].apply(
    lambda x: "High" if x >= 2 else "Medium" if x == 1 else "Low"
)

print(inventory[[
    "product_id", "warehouse", "closing_stock",
    "turnover_proxy", "stock_risk"
]])
