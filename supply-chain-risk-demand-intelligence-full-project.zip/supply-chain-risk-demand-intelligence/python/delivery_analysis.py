import pandas as pd

orders = pd.read_csv("../data/orders.csv")

orders["delay_flag"] = orders["status"].eq("Delayed").astype(int)

print("Average delivery days:", round(orders["delivery_days"].mean(), 2))
print("Delayed orders:", orders["delay_flag"].sum())
print("Delay rate: {:.2f}%".format(orders["delay_flag"].mean() * 100))

print("\nWarehouse delivery performance:")
print(orders.groupby("warehouse").agg(
    orders=("order_id", "count"),
    avg_delivery_days=("delivery_days", "mean"),
    delayed_orders=("delay_flag", "sum")
))
