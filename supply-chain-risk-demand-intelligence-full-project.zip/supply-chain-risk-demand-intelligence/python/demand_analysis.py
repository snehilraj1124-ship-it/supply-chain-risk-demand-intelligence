import pandas as pd

orders = pd.read_csv("../data/orders.csv")
products = pd.read_csv("../data/products.csv")

orders["revenue"] = orders["quantity"] * orders["unit_price"]

summary = orders.groupby("product_id").agg(
    units=("quantity", "sum"),
    revenue=("revenue", "sum"),
    avg_delivery_days=("delivery_days", "mean")
).reset_index()

summary = summary.merge(products[["product_id", "product_name", "category"]], on="product_id")
summary = summary.sort_values("units", ascending=False)

print(summary)
summary.to_csv("../reports/demand_summary.csv", index=False)
