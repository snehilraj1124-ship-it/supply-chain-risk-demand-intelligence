from demand_analysis import orders, products, summary
from inventory_metrics import inventory
from supplier_score import suppliers

print("\n=== SUPPLY CHAIN INTELLIGENCE PIPELINE ===")
print("Products analysed:", len(products))
print("Orders analysed:", len(orders))
print("Inventory records:", len(inventory))
print("Suppliers analysed:", len(suppliers))
print("Top demand product:", summary.iloc[0]["product_name"])
