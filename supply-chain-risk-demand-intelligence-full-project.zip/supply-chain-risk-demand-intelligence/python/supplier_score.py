import pandas as pd

suppliers = pd.read_csv("../data/suppliers.csv")

suppliers["performance_score"] = (
    suppliers["on_time_rate"] * 70
    + (1 - suppliers["defect_rate"]) * 20
    + (1 / suppliers["avg_lead_days"]) * 10
)

suppliers["calculated_risk"] = suppliers["performance_score"].apply(
    lambda x: "Low" if x >= 85 else "Medium" if x >= 75 else "High"
)

print(suppliers[[
    "supplier_id", "supplier_name",
    "performance_score", "calculated_risk"
]])
